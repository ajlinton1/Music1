IdSharp - A tagging library for .NET 2.0
http://www.idsharp.com

ALPHA RELEASE - PLEASE TEST ON BACKUPS

bin       	- idsharp.dll, idsharp.xml
harness\bin     - c# and vb6 exe's
harness\source  - c# and vb6 sources
reference       - api reference

Release notes:

0.0.0.2 - 2007-02-17 - COM interop enhancements; VB6 harness app added; 
                       Changes for iTunes compatability
0.0.0.1 - 2007-02-03 - Initial public release
